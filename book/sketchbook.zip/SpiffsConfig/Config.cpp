// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#include "Config.h"

void ApConfig::save(JsonObject& obj) const {
  obj["ssid"] = ssid;
  obj["passphrase"] = passphrase;
}

void ApConfig::load(const JsonObject& obj) {
  strlcpy(ssid, obj["ssid"] | "", sizeof(ssid));
  strlcpy(passphrase, obj["passphrase"] | "", sizeof(passphrase));
}

void ServerConfig::save(JsonObject& obj) const {
  obj["username"] = username;
  obj["password"] = password;
  obj["host"] = host;
  obj["path"] = path;
}

void ServerConfig::load(const JsonObject& obj)
{
  strlcpy(username, obj["username"] | "", sizeof(username));
  strlcpy(password, obj["password"] | "", sizeof(password));
  strlcpy(host, obj["host"] | "", sizeof(host));
  strlcpy(path, obj["path"] | "", sizeof(path));
}

void Config::load(const JsonObject& obj) {
  // Read "server" object
  server.load(obj["server"]);

  // Extract each access points
  JsonArray &aps = obj["access_points"];
  accessPoints = 0;
  for (JsonObject &ap : aps) {
    // Load the AP
    accessPoint[accessPoints].load(ap);

    // Increment AP count
    accessPoints++;

    // Max reach?
    if (accessPoints >= maxAccessPoints) break;
  }
}

void Config::save(JsonObject& obj) const {
   // Add "server" object
  server.save(obj.createNestedObject("server"));

  // Add "acces_points" array
  JsonArray& aps = obj.createNestedArray("access_points");

  // Add each acces point in the array
  for(int i=0; i<accessPoints; i++)
    accessPoint[i].save(aps.createNestedObject());
}

bool serializeConfig(const Config &config, Print& dst) {
  DynamicJsonBuffer jb(512);

  // Create an object
  JsonObject &root = jb.createObject();

  // Fill the object
  config.save(root);

  // Serialize JSON to file
  return root.prettyPrintTo(dst);
}

bool deserializeConfig(Stream& src, Config &config) {
  DynamicJsonBuffer jb(1024);

  // Parse the JSON object in the file
  JsonObject &root = jb.parseObject(src);
  if (!root.success()) return false;

  config.load(root);
  return true;
}
