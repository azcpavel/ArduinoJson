// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#pragma once

struct Forecast {
  long dt;
  float temp;
  char weather[64];
};

int fetchForecast(const char *key, const char *query, Forecast *forecasts,
                  int maxForecasts);