// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#include <ArduinoJson.h>
#include <WiFi101.h>

#include "Forecast.h"

// Sends the HTTP request
static bool sendRequest(Print &client, const char *key, const char *query) {
  client.print("GET /data/2.5/forecast?q=");
  client.print(query);
  client.print("&units=metric&appid=");
  client.print(key);
  client.println(" HTTP/1.0");
  client.println("Host: api.openweathermap.org");
  client.println("Connection: close");
  return client.println() != 0;
}

// Verify the HTTP status
static bool checkResponse(Stream &client) {
  char status[32];
  client.readBytesUntil('\r', status, sizeof(status));

  // should be "HTTP/1.0 200 OK"
  return strcmp(status + 9, "200 OK") == 0;
}

// Skip all bytes until we are in the "list" array
static bool jumbToList(Stream &stream) {
  char beginingOfList[] = "\"list\":[";
  return stream.find(beginingOfList);
}

// Skip all bytes until we found a comma of a closing bracket
static bool jumpToNextElement(Stream &stream) {
  char comma[] = ",";
  char endOfArray[] = "]";
  return stream.findUntil(comma, endOfArray);
}

static bool deserializeForecast(Stream &stream, Forecast &f) {
  StaticJsonBuffer<1024> jb;

  JsonObject &obj = jb.parseObject(stream);
  if (!obj.success())
    return false;

  f.dt = obj["dt"];
  f.temp = obj["main"]["temp"];
  strlcpy(f.weather, obj["weather"][0]["description"] | "N/A",
          sizeof(f.weather));
  return true;
}

int fetchForecast(const char *key, const char *query, Forecast *forecasts,
                  int maxForecasts) {
  WiFiClient client;

  // Send HTTP request
  if (!client.connect("api.openweathermap.org", 80)) {
    Serial.println("Failed to connect to server");
    return 0;
  }

  // Make a HTTP request
  if (!sendRequest(client, key, query)) {
    Serial.println(F("Failed to send request"));
    return 0;
  }

  // Check response code
  if (!checkResponse()) {
    Serial.print(F("Unexpected HTTP status"));
    return 0;
  }

  // The JSON response is gigantic, but we are only interested in the array
  // "forecastday" within the object "simpleforecast".
  //
  //      "list": [
  //
  // So we skip all the response until we find the start of the array.
  if (!jumbToList(client)) {
    Serial.println(F("Array \"list\" is missing from response"));
    return 0;
  }

  int n = 0;
  while (n < maxForecasts) {
    // We are now in the array, we can read the objects one after the other
    if (!deserializeForecast(client, forecasts[n++])) {
      Serial.println(F("Failed to parse forecastday"));
      break;
    }

    // After reading a forecast object, the next character is either a
    // comma (,) or the closing bracket (])
    if (!jumpToNextElement(client))
      break;
  };

  client.stop();
  return n;
}
