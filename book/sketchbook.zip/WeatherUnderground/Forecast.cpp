// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#include <ArduinoJson.h>
#include <ESP8266HTTPClient.h>

#include "Forecast.h"

// Skip all bytes until we are in the "simpleforecast.forecastday" array
static bool jumbToSimpleForecast(Stream &stream) {
  return stream.find("\"simpleforecast\"") &&
         stream.find("\"forecastday\"") &&
         stream.find("[");
}

// Skip all bytes until we found a comma of a closing bracket
static bool jumpToNextElement(Stream &stream) {
  return stream.findUntil(",", "]");
}

static bool deserializeForecast(Stream &response, Forecast &f) {
  DynamicJsonBuffer jb(2048);

  JsonObject &obj = jb.parseObject(response);
  if (!obj.success())
    return false;

  f.conditions = obj["conditions"].as<char *>();
  f.high = obj["high"]["celsius"];
  f.low = obj["low"]["celsius"];
  f.weekday = obj["date"]["weekday"].as<char *>();
  return true;
}

int fetchForecast(String key, String query, Forecast *forecasts,
                  int maxForecasts) {
  String url = "http://api.wunderground.com/api/" + key + "/forecast10day/q/" +
               query + ".json";

  HTTPClient http;

  // Send HTTP request
  http.begin(url);
  if (http.GET() != 200) {
    Serial.println(F("HTTP request failed"));
    return 0;
  }

  // Get a reference to the response
  Stream &response = http.getStream();

  // The JSON response is gigantic, but we are only interested in the array
  // "forecastday" within the object "simpleforecast".
  //
  //    "simpleforecast": {
  //      "forecastday": [
  //
  // So we skip all the response until we find the start of the array.
  if (!jumbToSimpleForecast(response)) {
    Serial.println(F("Object \"simpleforecast\" is missing from response"));
    return 0;
  }

  int n = 0;
  while (n < maxForecasts) {
    // We are now in the array, we can read the objects one after the other
    if (!deserializeForecast(response, forecasts[n++])) {
      Serial.println(F("Failed to parse forecastday"));
      break;
    }

    // After reading a forecast object, the next character is either a
    // comma (,) or the closing bracket (])
    if (!jumpToNextElement(response))
      break;
  };

  http.end();
  return n;
}