// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#pragma once

struct Forecast {
  String weekday;
  String conditions;
  int high;
  int low;
};

int fetchForecast(String key, String query, Forecast *forecasts,
                  int maxForecasts);
