// This is a class from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon
//
// This file is released under the term of the MIT License.
// Feel free to reuse.
//
// Example:
//   PrintLogger logger(wifiClient);
//   obj.printTo(logger);

// Adds logging to an instance of Print
class PrintLogger : public Print {
public:
  // Constructs a PrintLogger attached to the specified target
  PrintLogger(Print &target) : _target(target) {
  }

  // Writes a single byte
  virtual size_t write(uint8_t c) {
    // Log to the serial
    Serial.write(c);
    // then delegate to the target
    return _target.write(c);
  }

  // Writes multiple bytes
  virtual size_t write(const uint8_t *buffer, size_t size) {
    // Log to the serial
    Serial.write(buffer, size);
    // then delegate to the target
    return _target.write(buffer, size);
  }

  // Flushes temporary buffers
  virtual size_t flush() {
    // Delegate to the target
    return _target.flush();
  }

private:
  Print &_target;
};