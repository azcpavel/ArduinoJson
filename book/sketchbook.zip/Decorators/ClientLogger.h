// This is a class from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon
//
// This file is released under the term of the MIT License.
// Feel free to reuse.
//
// Example:
//   ClientLogger logger(wifiClient);
//   logger.connect(host, port);
//   logger.println("GET /resource HTTP/1.0");
//   ...

// Adds logging to an instance of Client
class ClientLogger : public Client {
public:
  // Constructs a ClientLogger attached to the specified target
  ClientLogger(Client &target) : _target(target) {
  }

  // Establishes TCP connection
  virtual int connect(IPAddress ip, uint16_t port) {
    // Log
    Serial.print(F("Connect to "));
    Serial.print(ip);
    Serial.print(':');
    Serial.println(port);

    // Delegate
    int result = _target.connect(ip, port);

    // Log
    if (result)
      Serial.println("Connection established");
    else
      Serial.println("Connection failed");

    // Pretend nothing happened
    return result;
  }

  // Establishes TCP connection
  virtual int connect(const char *host, uint16_t port) {
    // Log
    Serial.print(F("Connect to "));
    Serial.print(host);
    Serial.print(':');
    Serial.println(port);

    // Delegate
    int result = _target.connect(host, port);

    // Log
    if (result)
      Serial.println("Connection established");
    else
      Serial.println("Connection failed");

    // Pretend nothing happened
    return result;
  }

  // Closes the connection
  virtual void stop() {
    // Log
    Serial.println("Disconnect");
    // Delegate to target
    return _target.stop();
  }

  // Pops multiple bytes from the stream
  virtual int read(uint8_t *buf, size_t size) {
    // Delegate to the target
    int n = _target.read(buf, size);

    // Log if something was returned
    Serial.write(buf, n);

    // Pretend nothing happened
    return n;
  }

  // Pops the next byte from the stream
  virtual int read() {
    // Delegate to the target
    int c = _target.read();

    // Log if something was returned
    if (c > 0)
      Serial.print((char)c);

    // Pretend nothing happened
    return c;
  }

  // Gets the number of bytes available
  virtual int available() {
    // Delegate to target
    return _target.available();
  }

  // Gets the next byte in the stream (but doesn't pop it)
  virtual int peek() {
    // Delegate to target
    return _target.peek();
  }

  // Writes a single byte
  virtual size_t write(uint8_t c) {
    // Log
    Serial.write(c);
    // Delegate to target
    return _target.write(c);
  }

  // Writes multiple bytes
  virtual size_t write(const uint8_t *buffer, size_t size) {
    // Log
    Serial.write(buffer, size);
    // Delegate to target
    return _target.write(buffer, size);
  }

  // Flushes temporary buffers
  virtual void flush() {
    Serial.println("Flush");
    // Delegate to target
    return _target.flush();
  }

  virtual uint8_t connected() {
    return _target.connected();
  }

  virtual operator bool() {
    return _target.operator bool();
  }

private:
  Client &_target;
};