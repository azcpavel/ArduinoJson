// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#pragma once

#include "JsonRpc.h"

struct KodiVersion {
  char name[32];
  char tag[32];
  int major;
  int minor;
};

class KodiClient {
public:
  KodiClient(const char *host, short port) : _client(host, port) {
  }

  // Displays a notification on Kodi
  bool showNotification(const char *title, const char *message);

  // Gets Kodi version
  bool getVersion(KodiVersion &v);

private:
  JsonRpcClient _client;
};
