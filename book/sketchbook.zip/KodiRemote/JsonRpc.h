// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#pragma once

#include <ArduinoJson.h>
#include <Ethernet.h>
#include <SPI.h>

// A JSON-RPC Request
class JsonRpcRequest {
  StaticJsonBuffer<512> _jb;
  JsonObject &_root;

public:
  JsonRpcRequest(const char *method);

  // Computes Content-Length
  size_t length() const {
    return _root.measureLength();
  }

  // Serializes the request
  size_t printTo(Print &client) const {
    return _root.printTo(client);
  }

  JsonObject &params;
};

// A JSON-RPC Response
class JsonRpcResponse {
  StaticJsonBuffer<512> _jb;

public:
  // Deserializes the response
  bool parse(Stream &stream);

  JsonVariant result;
  JsonVariant error;
};

// A client for JSON-RPC
class JsonRpcClient {
public:
  JsonRpcClient(const char *host, short port) : _host(host), _port(port) {
  }

  // Closes connection
  ~JsonRpcClient() {
    _client.stop();
  }

  // Sends a JSON-RPC Request
  bool send(const JsonRpcRequest &req);

  // Receives a JSON-RPC Response
  bool recv(JsonRpcResponse &res);

private:
  EthernetClient _client;
  const char *_host;
  short _port;
};