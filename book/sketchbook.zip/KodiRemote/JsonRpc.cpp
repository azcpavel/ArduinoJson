// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#include "JsonRpc.h"

JsonRpcRequest::JsonRpcRequest(const char *method)
    : _jb(), _root(_jb.createObject()),
      params(_root.createNestedObject("params")) {
  _root["method"] = method;
  _root["jsonrpc"] = "2.0";
  _root["id"] = 1;
}

bool JsonRpcResponse::parse(Stream &stream) {
  JsonObject &root = _jb.parse(stream);
  result = root["result"];
  error = root["error"];
  return root.success();
}

bool JsonRpcClient::send(const JsonRpcRequest &req) {
  // Reconnect if needed
  if (!_client.connected() && !_client.connect(_host, _port)) {
    Serial.println(F("Connection failed."));
    Serial.println(F("Check IP, port, firewall and Kodi settings."));
    return false;
  }

  // Send the HTTP headers
  _client.println(F("POST /jsonrpc HTTP/1.0"));
  _client.println(F("Content-Type: application/json"));
  _client.println(F("Connection: keep-alive"));
  _client.print(F("Content-Length: "));
  _client.println(req.length());
  _client.println();

  // Send JSON document in body
  req.printTo(_client);

  return true;
}

bool JsonRpcClient::recv(JsonRpcResponse &res) {
  // Check HTTP status (should be "HTTP/1.0 200 OK")
  char status[32] = {0};
  _client.readBytesUntil('\r', status, sizeof(status));
  if (strcmp(status + 9, "200 OK") != 0) {
    Serial.print(F("Unexpected status: "));
    Serial.println(status);
    return false;
  }

  // Skip HTTP headers
  char endOfHeaders[] = "\r\n\r\n";
  if (!_client.find(endOfHeaders)) {
    Serial.print(F("Response contains no body"));
    return false;
  }

  // Parse body
  if (!res.parse(_client)) {
    Serial.println("Failed to parse JSON response");
    return false;
  }

  // Is there an error in the response?
  if (res.error.is<JsonObject>()) {
    Serial.println(F("JSON RPC error: "));
    res.error.prettyPrintTo(Serial);
    Serial.println();
    return false;
  }

  return true;
}
