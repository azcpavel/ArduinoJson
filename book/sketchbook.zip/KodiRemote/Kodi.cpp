// This is a sample file from the book "Mastering ArduinoJson"
// https://leanpub.com/arduinojson/
// Copyright 2017 Benoit Blanchon

#include "Kodi.h"

bool KodiClient::showNotification(const char *title, const char *message) {
  // Request scope
  {
    JsonRpcRequest req("GUI.ShowNotification");
    req.params["title"] = title;
    req.params["message"] = message;

    if (!_client.send(req))
      return false;
  }
  // Response scope
  {
    JsonRpcResponse res;
    _client.recv(res);
    return res.result == "OK";
  }
}

bool KodiClient::getVersion(KodiVersion &v) {
  // Request scope
  {
    JsonRpcRequest req("Application.GetProperties");
    JsonArray &properties = req.params.createNestedArray("properties");
    properties.add("name");
    properties.add("version");

    if (!_client.send(req))
      return false;
  }
  // Response scope
  {
    JsonRpcResponse res;
    if (!_client.recv(res))
      return false;

    strlcpy(v.name, res.result["name"] | "", sizeof(v.name));
    v.major = res.result["version"]["major"];
    v.minor = res.result["version"]["minor"];
    strlcpy(v.tag, res.result["version"]["tag"] | "", sizeof(v.tag));
    return true;
  }
}
